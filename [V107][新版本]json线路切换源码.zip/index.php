<?php

use Config\Config;
use Lib\Core;
use Lib\Tools\Cache;
use Lib\Tools\Client;

const __App__ = __DIR__;
const APP_VERSION = "1.0.7";

require_once __App__ . '/vendor/autoload.php';

if (Config::cross) {
    header("Access-Control-Allow-Origin: *");
}

if (!Config::debug) {
    error_reporting(0);
}

if (PHP_VERSION < 8.0) {
    exit('请将PHP版本提高到8.0即以上.');
}

$type = $_GET['type'] ?? null;
switch ($type) {
    case "clear":
        $pass = $_GET['pass'] ?? null;
        if (null == $pass || $pass != Config::clearCachePass) {
            Core::parsing()->json(Config::codeFail, 'pass error');
        }
        $count = Cache::clearCache(Config::cachePath);
        Core::parsing()->json(Config::codeSuccess, $count == 0 ? '还没有到期缓存哦~,请稍后清理' : '成功清理了' . $count . '个过期缓存~', [
            "count" => $count
        ]);
        break;
    case "handle":
        try {
            $handle = $_GET['handle'] ?? null;
            if (null == $handle) {
                Core::parsing()->json(Config::codeFail, 'handle error');
            }
            $name = "Handler\\Achieve\\{$handle}";
            $class = new $name();
            if (!method_exists($class, 'visit')) {
                Core::parsing()->json(Config::codeFail, 'function error');
            }
            call_user_func([$class, "visit"]);
        } catch (Throwable $exception) {
            if (!Config::debug) {
                Core::parsing()->json(Config::codeFail, 'class exception');
            }
            Core::parsing()->json(Config::codeFail, $exception->getMessage());
        }
        break;
    default:
        if (Config::clientAuthorize) {
            if (!in_array(Client::getClientIp(), Config::authClient)) {
                Core::parsing()->json(Config::codeFail, Config::authErrorMsg);
            }
        }
        $url = $_GET['url'] ?? null;
        if (empty($url)) {
            Core::parsing()->json(Config::codeFail, '请输入url进行解析.');
        }
        try {
            //开始解析
            Core::parsing()->init($url, [])->run();
        } catch (Throwable $exception) {
            if (!Config::debug) {
                Core::parsing()->json(Config::codeFail, 'parsing exception');
            }
            Core::parsing()->json(Config::codeFail, $exception->getMessage());
        }
}