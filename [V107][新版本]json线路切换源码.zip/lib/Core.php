<?php

namespace Lib;

use Config\Config;
use Config\Expand;
use Constant\Line;

class Core
{

    private static ?object $instance = null;

    // 禁止被实例化
    private function __construct()
    {
    }

    // 禁止clone
    private function __clone()
    {
    }

    //  实例化自己并保存到$instance中，已实例化则直接调用
    public static function parsing(): Core
    {
        if (empty(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //Json消息回馈
    public function json(int $code = 200, string $message = null, array $extra = []): void
    {
        $return = ["code" => $code, "message" => $message];

        if (!empty($extra)) $return = array_merge($return, $extra);
        if (!empty(Expand::get()->jsonResponse)) $return = array_merge($return, Expand::get()->jsonResponse);

        header("content-type:application/json");
        exit(json_encode($return, JSON_UNESCAPED_UNICODE));
    }

    //初始化
    public function init(string $url, array $config = []): Handle
    {
        require_once __App__ . '/lib/Handle.php';
        $replaceData = require_once __App__ . '/config/Replace.php';

        $urlMatch = parse_url($url);
        if (!isset($urlMatch['scheme'])) {
            if (empty(Config::whitelist)) $this->json(Config::codeFail, '无效的输入数据!');
            $white = false;
            foreach (Config::whitelist as $list) {
                if (strstr($url, $list)) {
                    $white = true;
                }
            }
            if (!$white) $this->json(Config::codeFail, '无效的输入数据!');
        }

        $direct = false;
        if (!Config::m3u8Parse) {
            if (str_contains($url, '.m3u8')) {
                $direct = true;
            }
        }
        if (!empty(Config::direct)) {
            foreach (Config::direct as $value) {
                if (strstr($url, $value)) {
                    $direct = true;
                }
            }
        }

        $replaceUrl = null;
        if (!empty($replaceData)) {
            foreach ($replaceData as $data) {
                if (true === $data['run']) {
                    foreach ($data['match'] as $match) {
                        if ($match == $url) {
                            if (true === $data['parse']) {
                                $direct = false;
                                $replaceUrl = $data['replace'];
                            } else {
                                $direct = true;
                            }
                        }
                    }
                }
            }
        }

        if ($replaceUrl != null && $direct === false) {
            $url = $replaceUrl;
        }

        if (false === $direct) {
            $grouping = $this->matchGrouping($url);
            $lineData = $this->matchLine($grouping);
        }

        $handle = new Handle();

        $handle->url = $url;
        $handle->config = $config;
        $handle->matchGroup = !empty($grouping) ? $grouping : [];
        $handle->lineGroup = !empty($lineData) ? $lineData : [];
        $handle->replaceData = $replaceData;

        return $handle;
    }

    #线路筛选
    public function matchLine(array $grouping): array
    {
        $lineGroup = Config::lineGroup;
        if (empty($lineGroup)) $this->json(Config::codeFail, '请先配置一个线路后在进行解析,如果该站点不是您的请联系管理员!');

        $matchData = [];
        foreach ($lineGroup as $index => $line) {
            if (!isset($line[Line::Run]) || !$line[Line::Run]) {
                continue;
            }

            if (empty($line[Line::Match])) {
                continue;
            }
            if (!isset($line[Line::Priority])) $line[Line::Priority] = 0;
            foreach ($line[Line::Match] as $match) {
                if (in_array($match, $grouping)) {
                    $matchData[$index] = $line;
                }
            }
        }

        $matchData = array_merge($matchData);

        if (empty($matchData)) $this->json(Config::codeFail, '没有匹配上可用的线路配置,请重新输入一个网址~');

        $descKey = array_column($matchData, Line::Priority);
        array_multisort($descKey, SORT_DESC, $matchData);

        return $matchData;
    }

    #分组处理
    public function matchGrouping($url): array
    {
        $matchGroup = Config::matchGroup;

        if (empty($matchGroup)) $this->json(Config::codeFail, '请先配置一个分组后在进行解析,如果该站点不是您的请联系管理员!');

        $matchData = [];
        $allMatch = [];
        foreach ($matchGroup as $name => $group) {

            if (empty($group['match'])) continue;

            if ($group['match'] === "*") {
                $allMatch[] = $name;
                continue;
            }

            if (!str_contains($group['match'], '|')) {
                if (strstr($url, $group['match'])) {
                    if (!in_array($name, $matchData)) $matchData[] = $name;
                }
            }

            $match = explode('|', $group['match']);
            foreach ($match as $value) {
                if (empty($value)) continue;
                if (strstr($url, $value)) {
                    if (!in_array($name, $matchData)) $matchData[] = $name;
                }
            }
        }

        if (!empty($allMatch)) $matchData = array_merge($matchData, $allMatch);
        if (empty($matchData)) $this->json(Config::codeFail, '没有匹配上可用的分组配置,请重新输入一个网址~');

        return $matchData;
    }
}