<?php

namespace Lib\Tools;

class File
{
    /**
     * 验证是否存在文件夹(不存在创建)
     * @param string $dir
     * @param int $mode
     * @return bool
     */
    public static function mkdirs(string $dir, int $mode = 0777): bool
    {
        if (is_dir($dir) || @mkdir($dir, $mode)) return true;
        if (!self::mkdirs(dirname($dir), $mode)) return false;
        return @mkdir($dir, $mode);
    }

    /**
     * 获取目录文件
     * @param string $path
     * @return array
     */
    public static function pathDir(string $path): array
    {
        //针对当前目录的情况下
        $dir = scandir($path);
        $fileList = [];
        if (!empty($dir)) {
            foreach ($dir as $file) {
                if ($file != '.' && $file != '..') {
                    $fileList[] = $file;
                }
            }
        }
        return $fileList;
    }


    /**
     * 删除文件(递归)
     * @param $path
     * @return void
     */
    public static function deleteDir($path)
    {
        if (is_dir($path)) {
            //扫描一个目录内的所有目录和文件并返回数组
            $dirs = scandir($path);
            foreach ($dirs as $dir) {
                //排除目录中的当前目录(.)和上一级目录(..)
                if ($dir != '.' && $dir != '..') {
                    //如果是目录则递归子目录，继续操作
                    $sonDir = $path . '/' . $dir;
                    if (is_dir($sonDir)) {
                        //递归删除
                        self::deleteDir($sonDir);
                        //目录内的子目录和文件删除后删除空目录
                        @rmdir($sonDir);
                    } else {
                        //如果是文件直接删除
                        @unlink($sonDir);
                    }
                }
            }
            @rmdir($path);
        }
    }
}