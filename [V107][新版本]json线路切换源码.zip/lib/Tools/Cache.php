<?php

namespace Lib\Tools;

use Config\Config;
use Lib\Core;

class Cache
{

    public static function dirIsExist()
    {
        $path = __App__ . '/runtime';
        if (!is_readable($path)) {
            is_file($path) or mkdir($path, 0700);
        }
    }

    /**
     * 目录扫描
     * @param string $path
     * @return array
     */
    private static function pathDir(string $path): array
    {
        //针对当前目录的情况下
        $dir = scandir($path);
        $fileList = [];
        foreach ($dir as $file) {
            if ($file != '.' && $file != '..') {
                if (str_contains($file, '.json')) {
                    $fileList[] = $file;

                }
            }
        }
        return $fileList;
    }

    /**
     * 清理过期缓存
     * @param string $filePath
     * @return int
     */
    public static function clearCache(string $filePath): int
    {
        self::dirIsExist();
        $data = self::pathDir($filePath);
        $count = 0;
        if (!empty($data)) {
            foreach ($data as $files) {
                $path = $filePath . $files;
                $ret = json_decode(file_get_contents($path), true);
                if (isset($ret['timeout']) && $ret['timeout'] < time()) {
                    $count = $count + 1;
                    unlink($path);
                }
            }
        }
        return $count;
    }

    public static function getCache(string $filePath, string $name): array
    {
        self::dirIsExist();
        $filePath = $filePath . '/' . md5($name) . '.json';
        if (!file_exists($filePath)) {
            return [];
        }
        $json = file_get_contents($filePath);
        $ret = json_decode($json, true);
        if (isset($ret['timeout']) && $ret['timeout'] < time()) {
            unlink($filePath);
            return [];
        }
        return $ret['data'];
    }

    public static function setCache(string $filePath, string $name, array $data, int $timeout = 0): void
    {
        self::dirIsExist();
        $filePath = $filePath . '/' . md5($name) . '.json';
        $array = [
            "data" => $data,
        ];
        if ($timeout != 0) {
            $array['timeout'] = time() + $timeout;
        }
        $ret = json_encode($array);
        if (file_put_contents($filePath, $ret) === false) {
            Core::parsing()->json(Config::codeFail, '没有写入权限...');
        }
    }
}