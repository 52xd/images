<?php

namespace Lib\Tools;

use Config\Config;
use Lib\Core;

class Aes
{
    //创建静态私有的变量保存该类对象
    static private $instance;

    static private string $encryptKey = "1234567892222222";

    static private string $localIV = "1234567893333333";

    //防止使用new直接创建对象
    private function __construct()
    {
    }

    //防止使用clone克隆对象
    private function __clone()
    {
    }

    static public function getInstance(string $encryptKey = "", string $localIV = ""): Aes
    {
        if (!empty($encryptKey)) {
            if (strlen($encryptKey) > 16 || strlen($encryptKey) < 16) {
                Core::parsing()->json(Config::codeFail,'encryptKey不能大于或者小于16位字符串');
            }
            self::$encryptKey = $encryptKey;
        }

        if (!empty($localIV)) {
            if (strlen($localIV) > 16 || strlen($localIV) < 16) {
                Core::parsing()->json(Config::codeFail,'localIV不能大于或者小于16位字符串');
            }
            self::$localIV = $localIV;
        }

        if (!self::$instance instanceof self) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AES/CBC 加密
     * @param $data
     * @return string
     */
    public function encrypt($data): string
    {
        return base64_encode(openssl_encrypt($data, 'aes-128-cbc', self::$encryptKey, OPENSSL_RAW_DATA, self::$localIV));
    }

    /**
     * AES/CBC 解密
     * @param $data
     * @return bool|string
     */
    public function decrypt($data): bool|string
    {
        return openssl_decrypt(base64_decode($data), 'aes-128-cbc', self::$encryptKey, 1, self::$localIV);
    }
}