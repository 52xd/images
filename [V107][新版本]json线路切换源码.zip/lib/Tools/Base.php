<?php

namespace Lib\Tools;

class Base
{
    public static function getRandStr(int $length = 32): string
    {
        //字符组合
        $str = 'abcdefghijklmnopqrstuvwxyz';
        $len = strlen($str) - 1;
        $randStr = '';
        for ($i = 0; $i < $length; $i++) {
            $num = mt_rand(0, $len);
            $randStr .= $str[$num];
        }
        return $randStr;
    }
}