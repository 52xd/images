<?php

namespace Lib\Tools;

use GuzzleHttp\Client;

class Http
{
    public static function create(): Client
    {
        return new Client([
            "verify" => false
        ]);
    }
}