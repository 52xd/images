<?php

namespace Lib;

use Config\Config;
use Constant\Line;
use Constant\LineCache;
use Constant\LineHandle;
use Lib\Tools\Cache;
use Lib\Tools\Http;

class Handle
{
    public string $url;

    public array $lineGroup;

    public array $matchGroup;

    public array $config;

    public array $replaceData;

    public function run(): void
    {
        $cache = Cache::getCache(Config::cachePath, $this->url);

        if (!empty($cache)) {
            $videoUrl = $cache['feedback'];
        } else {
            $videoUrl = $this->request();
        }

        Core::parsing()->json(Config::codeSuccess, 'success', [
            "url" => $videoUrl
        ]);
    }

    public function request(): ?string
    {
        $videoUrl = null;

        $replaceUrl = $this->replace();
        if ($replaceUrl != null) {
            $videoUrl = $replaceUrl;
        }
        if ($videoUrl == null && empty($this->lineGroup)) {
            $videoUrl = $this->url;
        }
        if ($videoUrl == null) {
            foreach ($this->lineGroup as $line) {
                try {
                    $handleForward = false;//处理前
                    $handleAfter = false;//处理后

                    if (isset($line[Line::Handle]) && is_array($line[Line::Handle])) {
                        if (isset($line[Line::Handle][LineHandle::Forward])) $handleForward = true;
                        if (isset($line[Line::Handle][LineHandle::After])) $handleAfter = true;
                    }

                    $feedback = null;
                    $parsing = true;
                    if ($handleForward) {
                        $feedback = $this->handle(new $line[Line::Handle][LineHandle::Forward], ["line" => $line]);
                        if (null === $feedback) continue;
                        if ($feedback['parsing'] === false) $parsing = false;
                    }

                    $ret = null;
                    if (!isset($line[Line::Url]) && (isset($line[Line::Handle]) && !is_array($line[Line::Handle]))) {
                        $feedback = $this->handle(new $line[Line::Handle], ["line" => $line]);
                        if (null === $feedback) continue;
                        $ret = $feedback;
                    }

                    if (isset($line[Line::Url]) && $parsing) {
                        $ret = Http::create()->get($line['url'] . $this->url, [
                            "timeout" => (int)$line[Line::Timeout] ?? 10
                        ])->getBody()->getContents();
                        $ret = json_decode($ret, true);
                        if (isset($line[Line::Handle]) && !is_array($line[Line::Handle])) {
                            $feedback = $this->handle(new $line[Line::Handle], [
                                "line" => $line,
                                "url" => $ret['url']
                            ]);
                            if (null === $feedback) continue;
                            $ret = $feedback;
                        }
                    }

                    if ($handleAfter) {
                        $urlFunc = (function () use ($line, $parsing, $ret, $feedback) {
                            $url = null;
                            if (null !== $feedback) {
                                $url = $feedback['url'];
                                if (null !== $ret) {
                                    $url = $ret['url'];
                                }
                            }
                            return $url;
                        });
                        $feedback = $this->handle(new $line[Line::Handle][LineHandle::After], [
                            "line" => $line,
                            "url" => $urlFunc()
                        ]);
                        if (null === $feedback) continue;
                        $ret = $feedback;
                    }

                    if (empty($ret['url']) || preg_match("/[\x7f-\xff]/", $ret['url'])) continue;

                    $videoUrl = $ret['url'];
                    if (isset($line[Line::Cache]) && $line[Line::Cache][LineCache::Status]) {
                        Cache::setCache(Config::cachePath, $this->url, [
                            "feedback" => $videoUrl
                        ], $line[Line::Cache][LineCache::Time]);
                    }
                    break;

                } catch (\Throwable $throwable) {
                    if (Config::debug) {
                        print_r($throwable->getMessage());
                    }
                    continue;
                }
            }
        }

        if ($videoUrl == null) {
            Core::parsing()->json(Config::codeFail, '无法解析到资源..');
        }

        return $videoUrl;
    }

    public function handle(object $class, array $data = []): ?array
    {
        if (!method_exists($class, 'achieve')) {
            return null;
        }

        $class->url = $this->url;
        if (isset($data['url'])) $class->url = $data['url'];
        if (isset($data['line'])) $class->line = $data['line'];

        $ret = call_user_func([$class, 'achieve']);
        if (false === $ret['set']) return null;
        return $ret;
    }

    #替换库
    public function replace(): ?string
    {
        $replaceData = $this->replaceData ?? null;
        if (empty($replaceData)) return null;
        $videoUrl = null;
        foreach ($replaceData as $data) {
            if (true === $data['run']) {
                if (false === $data['parse']) {
                    foreach ($data['match'] as $match) {
                        if ($match == $this->url) {
                            $videoUrl = $data['replace'];
                        }
                    }
                }
            }
        }
        return $videoUrl;
    }
}