<?php

namespace Config;

use Constant\Line;
use Constant\LineCache;
use Constant\LineHandle;

interface Config
{
    #【重要】开启调试模式(请不要随意开启)
    const debug = false;

    #【重要】程序跨域(如果配置了Nginx跨域请把该功能关闭)
    const cross = false;

    #客户授权制度(开启后只允许下方IP列表进行访问)
    const clientAuthorize = false;

    #授权客户列表【授权IP,一行一条】
    const authClient = [
        "8.8.8.8",
        "1.1.1.1"
    ];

    #客户授权制度(未授权提示)
    const authErrorMsg = "为防止滥用，本接口采取ip授权制,请联系站长开通您的IP.";

    #Json响应成功码
    const codeSuccess = 200;

    #Json响应错误码
    const codeFail = 100;

    #清理缓存密码
    #例子:https://127.0.0.1/?type=clear&pass=清理缓存密码
    const clearCachePass = "123456";

    #缓存目录(请不要随意修改)
    const cachePath = __App__ . '/runtime';

    #URL白名单
    #防止url乱输入做判断
    #列如 acg_12345... 如需要允许请添加 acg_或其他可作为唯一键
    const whitelist = [
        "TEST-"
    ];

    #M3U8直连是否进入解析
    #如果允许进入解析,请在匹配组添加.m3u8的匹配或*
    const m3u8Parse = false;

    #直连匹配数据除M3U8以外的配置数据
    const direct = [
        ".mp4",
        ".mkv"
    ];


    #匹配组
    #matchGroup(1~2)..为键名可自定义修改
    const matchGroup = [
        "matchGroup1" => [
            "match" => "iqiyi.com|youku.com|mgtv.com"//匹配值
        ],
        "matchGroup2" => [
            "match" => "OJBK-"//匹配值
        ],
        "test" => [
            "match" => "TEST-"//匹配值
        ]
    ];

    /**
     * 线路组
     * run 是否启动解析
     * timeout 是接口超时时间
     * priority 接口解析优先级,越大优先越高
     * handle 和 url 存 URL解析成功后处理给handle二次处理
     *         -handle 是处理程序(不懂不要乱写)
     *         -url 是Json解析API(一般使用该功能)
     * cache 缓存配置
     *          -status 缓存启动状态 [true启动|false停用]
     *          -cacheTime 缓存时间 [单位/秒]
     * match 解析分组配置
     *      -支持多条数据为matchGroup的配置建
     */
    const lineGroup = [
        [
            Line::Run => true,
            Line::Url => "https://www.baidu.com/?url=",
            Line::Timeout => 10,
            Line::Priority => 100,
            Line::Cache => [
                LineCache::Status => false,
                LineCache::Time => 100
            ],
            Line::Match => [
                "matchGroup1"
            ]
        ],
        [
            Line::Run => true,
            Line::Url => "https://www.baidu.com/?url=",
            Line::Timeout => 10,
            Line::Priority => 101,
            Line::Cache => [
                LineCache::Status => false,
                LineCache::Time => 100
            ],
            Line::Match => [
                "matchGroup1",
                "matchGroup2"
            ]
        ],
        [
            Line::Run => false,
            //自定义执行程序
            Line::Handle => \Handler\Achieve\UrlStrict::class,
            Line::Priority => 101,
            Line::Cache => [
                LineCache::Status => false,
                LineCache::Time => 100
            ],
            Line::Match => [
                "test"
            ]
        ]
    ];
}