<?php

/**
 * URL资源替换
 * title - 备注标题
 * replace - 替换资源
 * parse - 启动JSON解析
 * match - 匹配值 - 数组 [1,2,3,4]
 */
return [
    [
        "run" => false,
        "title" => "一拳超人 第一集",
        "replace" => "OJBK-E2997380F5AC34DFE0A643DF2A15",
        "parse" => true,
        "match" => [
            "https://v.youku.com/v_show/id_XMTM1MTc4MDU3Ng==.html",
            "https://v.youku.com/v_show/id_XMTM1NzI3MzE5Mg==.html"
        ],
    ],
    [
        "run" => false,
        "title" => "一拳超人 第二集",
        "replace" => "https://v.youku.com/v_show/id_XMTM1NzI3MzE5Mg==.html",
        "parse" => false,
        "match" => [
            "niubi",
        ],
    ]
];