<?php

namespace Config;

use Lib\Tools\Client;

class Expand
{
    #JSON响应扩展字段
    public array $jsonResponse = [
        "website" => "https://o.ls",
        "version" => APP_VERSION
    ];

    private static ?object $instance = null;

    // 防止被实例化
    private function __construct()
    {
        #JSON扩展字段新增【解决可执行方法问题】
        $this->jsonResponse['Time'] = date('Y-m-d H:i:s', time());//设置访问时间
        $this->jsonResponse['Ua'] = $_SERVER['HTTP_USER_AGENT'];//设置用户Ua
        $this->jsonResponse['Ip'] = Client::getClientIp();//用户IP
    }

    // 禁止clone
    private function __clone()
    {
    }

    //  实例化自己并保存到$instance中，已实例化则直接调用
    public static function get(): Expand
    {
        if (empty(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}