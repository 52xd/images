<?php

namespace Handler;

abstract class HandlerBase
{
    public array $line;

    public string $url;

    #系统内置set用做设置判断
    public bool $set = false;

    #处理成功后的url,请使用setUrlData赋值
    private string $videoUrl = "";

    #是否使用后期处理(默认开启)
    private bool $after = true;

    #如果存在解析url,是否进行解析
    private bool $parsing = true;

    protected function setAfter(bool $after): void
    {
        $this->after = $after;
    }

    protected function setParsing(bool $parsing): void
    {
        $this->parsing = $parsing;
    }

    protected function setUrlData(string $url): void
    {
        $this->set = true;
        $this->videoUrl = $url;
    }

    protected function feedback(): array
    {
        return [
            "url" => $this->videoUrl,
            "parsing" => $this->parsing,
            "after" => $this->after,
            "set" => $this->set
        ];
    }

    /**
     * 程序执行方法
     * @return array
     */
    abstract public function achieve(): array;

    /**
     * url访问方法
     * @return void
     */
    abstract public function visit(): void;
}