<?php

namespace Handler\Achieve;

use Handler\HandlerBase;
use Lib\Tools\Http;

/**
 * 严格的URL获取
 * 解决问题
 * https://xxx.com/?url=https://xxx.com/?url=xxxxx 二次问号的获取失败
 * 使用该模块的一个小BUG说明,如果需要加入其他参数请把url留在后一位!
 * 例子:https://xxx.com/?url=https://xxx.com/?miku=123&miku2=1234...&url=xxxxx
 */
class UrlStrict extends HandlerBase
{

    public function achieve(): array
    {
        $url = urldecode(http_build_query($_GET));
        preg_match_all("/(?<=url=).*/", $url, $data);
        $url = array_values($data[0]);

        $jsonApi = 'https://json.server.ci/mao.go?url=';
        $ret = Http::create()->get($jsonApi . $url[0])->getBody()->getContents();
        if (!empty($ret)) {
            $ret = json_decode($ret, true);
        }
        if (!empty($ret['url'])) {
            $this->setUrlData($ret['url']);
        }
        return $this->feedback();
    }

    /**
     * url访问方法
     * @return void
     */
    public function visit(): void
    {
        // TODO: Implement visit() method.
    }
}