<?php

namespace Constant;

interface Line
{
    #运行状态
    const Run = "run";

    #解析Url
    const Url = "url";

    #缓存列表
    const Cache = "cache";

    #解析优先级
    const Priority = "priority";

    #超时时间
    const Timeout = "timeout";

    #可执行程序
    const Handle = "handle";

    #匹配数组
    const Match = "match";
}