<?php

namespace Constant;

class LineCache
{
    const Status = "status";

    const Time = "cacheTime";


}