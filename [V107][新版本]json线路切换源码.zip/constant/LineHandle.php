<?php

namespace Constant;

class LineHandle
{
    #执行前(Url字段未被解析过)
    const Forward = "forward";

    #执行后(Url字段已被解析过)
    const After = "after";
}